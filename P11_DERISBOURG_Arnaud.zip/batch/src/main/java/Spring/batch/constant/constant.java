package Spring.batch.constant;

public interface constant {
    String APP_ROOT = "blibliotheque/v1";

}
