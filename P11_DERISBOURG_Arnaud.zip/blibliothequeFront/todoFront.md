> redirection vers la page de connexion après l'inscription

> créeation d'un prét côté backend

----