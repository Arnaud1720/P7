package com.arnaud.front.blibliothequeFront.configuration;

public interface constant {
    String APP_ROOT = "blibliotheque/v1";

}
