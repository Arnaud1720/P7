package com.arnaud.front.blibliothequeFront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlibliothequefrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
