package com.arnaud.back.blibliotheque.services;

public interface ExemplaryService {

}
