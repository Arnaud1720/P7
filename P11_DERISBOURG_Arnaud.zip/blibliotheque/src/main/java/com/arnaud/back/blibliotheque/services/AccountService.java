package com.arnaud.back.blibliotheque.services;

import com.arnaud.back.blibliotheque.model.Account;

public interface AccountService {

    Account save(Account account);

    Account findById(Integer id);


    void deleteById(Integer id);

    Account findAccountByMail(String mail);

     void validationEmail( String email ) throws Exception;

     void validationMotsDePasse( String motDePasse) throws Exception;
}
