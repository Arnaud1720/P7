package com.arnaud.back.blibliotheque.constant;

public interface Constants {

        String APP_ROOT = "blibliotheque/v1";
        String AUTHENTIFICATION_END_POINT = APP_ROOT+"/auth";
}
