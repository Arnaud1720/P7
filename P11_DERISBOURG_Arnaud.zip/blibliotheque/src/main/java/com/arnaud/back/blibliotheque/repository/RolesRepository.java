package com.arnaud.back.blibliotheque.repository;

import com.arnaud.back.blibliotheque.model.Roles;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolesRepository extends JpaRepository<Roles,Integer> {
}
