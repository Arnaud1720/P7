package com.arnaud.back.blibliotheque.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface BlibliothequeRepository {
}
