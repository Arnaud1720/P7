package com.arnaud.back.blibliotheque.services.impl;


import com.arnaud.back.blibliotheque.services.ExemplaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ExemplaryServicesImpl  {



}
