INSERT INTO public.blibliotheque (id, city, name, streetnumber, surface) VALUES (1, 'ville', 'nom', '25', 3200);
