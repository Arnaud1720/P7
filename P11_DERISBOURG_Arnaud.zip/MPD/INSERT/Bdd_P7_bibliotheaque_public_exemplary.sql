INSERT INTO public.exemplary (id, exemplairenumber, total_exemplary_number, remainingexemplary, id_blibliotheque) VALUES (1, 2, 4, 2, 1);
INSERT INTO public.exemplary (id, exemplairenumber, total_exemplary_number, remainingexemplary, id_blibliotheque) VALUES (2, 2, 4, 2, 1);
INSERT INTO public.exemplary (id, exemplairenumber, total_exemplary_number, remainingexemplary, id_blibliotheque) VALUES (3, 0, 6, 0, 1);
INSERT INTO public.exemplary (id, exemplairenumber, total_exemplary_number, remainingexemplary, id_blibliotheque) VALUES (4, 0, 6, 0, 1);
