INSERT INTO public.book (book_id, book_available, author, editor, kind, ref, synopsis, title, id_examplary) VALUES (1, true, 'auteur', 'éditeur', 'genre', '1', 'bla', 'tire', 1);
INSERT INTO public.book (book_id, book_available, author, editor, kind, ref, synopsis, title, id_examplary) VALUES (2, true, 'auteur2', 'éditeur2', 'genre2', '2', 'bla bla ', 'titre2', 2);
INSERT INTO public.book (book_id, book_available, author, editor, kind, ref, synopsis, title, id_examplary) VALUES (3, false, 'auteur3', 'éditeur3', 'genre3', '3', 'bla bla bla', 'titre3', 3);
INSERT INTO public.book (book_id, book_available, author, editor, kind, ref, synopsis, title, id_examplary) VALUES (4, false, 'auteur4', 'éditeur4', 'genre4', '4', 'bla bla bla bla', 'titre4', 4);
